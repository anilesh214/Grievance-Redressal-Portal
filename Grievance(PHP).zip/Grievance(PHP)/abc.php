<html>
<head>
<title>Public Grievances</title>
</head>
<body bgcolor="pink">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" />

<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>

<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"inputField",
			dateFormat:"%d-%M-%Y"
			/*selectedDate:{				This is an example of what the full configuration offers.
				day:5,						For full documentation about these settings please see the full version of the code.
				month:9,
				year:2006
			},
			yearsRange:[1978,2020],
			limitToToday:false,
			cellColorScheme:"beige",
			dateFormat:"%m-%d-%Y",
			imgPath:"img/",
			weekStartDay:1*/
		});
	};
</script> 

<tr>
<center><td><img SRC="DDA.jpg"  width=80%></center>
</td>
</tr>
</table>
<br>
<br>

<table bgcolor="blue" align="center" width=40% border="1">
<tr>
<td><center><font size=6>Grievance Registration Form</td>
</tr>
</table>
<br>
<br>

<table bgcolor="silver" align="center" width=20% border="1">
<tr>
<td><center><font size=6>Personal Details</td>
</tr>
</table>


<table width="300" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><form name="form1" method="post" action="insert.php">
<center><table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
</tr>
<tr>
<td width="71">Enter Your Name:</td>
<td width="6">:</td>
<td width="301"><input name="Name" type="text" id="Name" autocomplete="off"></td>
</tr>

<tr>
<td width="71">Date of birth:</td>
<td width="6">:</td>
<td width="301"><input name="inputField" type="text" id="inputField" autocomplete="off"></td>
</tr>

<tr>
<td>Address:</td>
<td>:</td>
<td><textarea name="Address" cols="40" rows="6" class="widebox" id="Address"></textarea></td>
</tr>