<?php

$host="localhost"; // Host name
$username="root"; // Mysql username
$password="22754196"; // Mysql password
$db_name="grievance"; // Database name
$tbl_name="lodge"; // Table name

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form
$Grievance_ID=$_POST['Grievance_ID'];
$Status=$_POST['Status'];
$Action=$_POST['Action'];

$sql="UPDATE lodge SET Status = '$Status', Action = '$Action' WHERE Grievance_ID = '$Grievance_ID'"; 


$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful".
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='action.php'>Back to main page</a>";
}

else {
echo "ERROR";
}
?>

<?php 