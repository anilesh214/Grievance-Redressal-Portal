<?php

if(isset($_SESSION['mydate'])){
header("location: checkdate.php");
}
?>

<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>database connections</title>
    </head>

    <body background="abc.jpg">
	<tr>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<table bgcolor="silver" align="center" width=20% border="1">
<tr>
<td><center><font size=6>CHECK STATUS</td>
</tr>
</table>
<br>
<br>

<table width="300" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><form name="form1" method="post" action="checkdate.php">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
</tr>

<tr>
<td width="71">From:</td>
<td width="6">:</td>
<td width="301"><input name="mydate" type="text" id="mydate" autocomplete="off"></td>
</tr>

<tr>
<td width="71">To:</td>
<td width="6">:</td>
<td width="301"><input name="mydate1" type="text" id="mydate1" autocomplete="off"></td>
</tr>
<tr>
<p><font color= red>Enter in form of: yyyy-mm-dd format</font>
</tr>
<tr>
<td colspan="3" align="center"><input type="submit" name="Submit" value="Submit"></td>
</tr>

</table>
</form>
</table>
<br>

<hr size=3" color=black>
<p><font size=4><center>||<a href="Index.php">Home<a>||</p>
<p><font size=4><center>Copyright � 2015</p>
<hr size=3" color=black>
      
    </body>
    </html>