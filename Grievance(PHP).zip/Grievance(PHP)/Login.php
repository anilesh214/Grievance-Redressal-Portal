<?php
include('indexes.php'); // Includes Login Script

if(isset($_SESSION['login_user'])){
header("location: profile.php");
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Login Form</title>
</head>
<body bgcolor="pink">
<center><td><img SRC="DDA.jpg"  width=80%></center>
</td>
</tr>
</table>
<br>
<br>

<table bgcolor="sky blue" align="center" width=60% >
<tr>
<td><center><font size=5>Login </td>
</tr>
</table>
<br>
<br>
<br>
<div id="main">
<div id="login">
<form action="" method="post">
<center><b>
<label>UserName :</label>
<input id="name" name="username" placeholder="username" type="text" autocomplete="off">
<p>
<br>
<label>Password :</label>
<input id="password" name="password" placeholder="**********" type="password">
<p>
<br>
<input name="submit" type="submit" value=" Login ">
<span><?php echo $error; ?></span>
</form>
</div>
</div>

<br>
<br>
<hr size=3" color=black>
<p><font size=4><center>||<a href="http://www.dda.org.in">DDA website<a>||<a href="contact.php">Contact Us<a>||<a href="index.php">Home<a>||</p>
<p><font size=4><center>Copyright � 2015 </p>
<hr size=3" color=black>

</body>
</html>