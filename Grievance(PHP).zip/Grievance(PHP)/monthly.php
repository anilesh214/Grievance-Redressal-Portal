<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>database connections</title>
    </head>
    <body background="abc.jpg">
	<tr>

      <?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
      $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/01/01' and '2015/01/31'");
      ?>
	<br>
	<br>
	<br>
	<br>
	<br>
	<hr size=3" color=black>
	<b id="Back"><a href="reports.php">Back</a></b>
	<hr size=3" color=black>
	<br>
	<br>

<p><center><font color=Blue><h1>January</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

 <?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/02/01' and '2015/02/29'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>February</h1>
     <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/03/01' and '2015/03/31'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>March</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/04/01' and '2015/04/30'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>April</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/05/01' and '2015/05/31'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>May</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/06/01' and '2015/06/30'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>June</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/07/01' and '2015/07/31'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>July</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/08/01' and '2015/08/31'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>August</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/09/01' and '2015/09/30'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>September</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/10/01' and '2015/10/31'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>October</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/11/01' and '2015/11/30'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>November</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

<?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
     $result = mysql_query("SELECT * FROM lodge WHERE mydate between '2015/12/01' and '2015/12/31'");
      ?>
	

	<br>
	<br>

<p><center><font color=Blue><h1>December</h1>
      <table border="2" style= "background-color: white; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>Grievance</th>
	<th>Action Taken</th>
	<th>Department</th>
	<th>Officer</th>
	<th>Landline_No</th>
	<th>Mobile_No</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['Description'\]}</td> 
	 <td>{$row\['Action'\]}</td> 
	      <td>{$row\['Dept'\]}</td> 
	      <td>{$row\['Officer'\]}</td> 
	      <td>{$row\['Landline_No'\]}</td> 
	      <td>{$row\['Mobile_No'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>

 </body>
</html>