<?php

$host="localhost"; // Host name
$username="root"; // Mysql username
$password="22754196"; // Mysql password
$db_name="grievance"; // Database name
$tbl_name="lodge"; // Table name

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");

// Get values from form
$Name=$_POST['Name'];
$inputField=$_POST['inputField'];
$Address=$_POST['Address'];
$District=$_POST['District'];
$Locality=$_POST['Locality'];
$PIN_Code=$_POST['PIN_Code'];
$State=$_POST['State'];
$Landline=$_POST['Landline'];
$Mobile=$_POST['Mobile'];
$Email=$_POST['Email'];
$Dept=$_POST['Dept'];
$Officer=$_POST['Officer'];
$Landline_No=$_POST['Landline_No'];
$Mobile_No=$_POST['Mobile_No'];
$Description=$_POST['Description'];
$Grievance_ID=$_POST['Grievance_ID'];

// Insert data into mysql
$sql="INSERT INTO $tbl_name(Name, inputField, Address, District, Locality, PIN_Code, State, Landline, Mobile, Email, Dept, Officer, Landline_No, Mobile_No,  Description, Grievance_ID)VALUES('$Name', '$inputField', '$Address', '$District', '$Locality', '$PIN_Code', '$State', '$Landline', '$Mobile', '$Email', '$Dept','$Officer', '$Landline_No', '$Mobile_No', '$Description', '$Grievance_ID')";

$result=mysql_query($sql);

// if successfully insert data into database, displays message "Successful".
if($result){
echo "Successful";
echo "<BR>";
echo "<a href='Index.php'>Back to main page</a>";
}

else {
echo "ERROR";
}
?>

<?php 