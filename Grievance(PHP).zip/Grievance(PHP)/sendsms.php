<html>
    <head>
    <script type="text/javascript">
    function load()
    {
    window.location.href = "http://smsc.dolphin.mtnldelhi.in/";

    }
    </script>
    </head>

    <body onload="load()">
    <h1>Hello World!</h1>
    </body>
    </html> 