<html>
<head>
<title>Public Grievances</title>
</head>
<link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" />
<script type="text/javascript" src="jsDatePick.min.1.3.js"></script>
<script type="text/javascript">
	window.onload = function(){
		new JsDatePick({
			useMode:2,
			target:"inputField",
			dateFormat:"%Y-%m-%d"
			/*selectedDate:{				This is an example of what the full configuration offers.
				day:5,						For full documentation about these settings please see the full version of the code.
				month:9,
				year:2006
			},
			yearsRange:[1978,2020],
			limitToToday:false,
			cellColorScheme:"beige",
			dateFormat:"%m-%d-%Y",
			imgPath:"img/",
			weekStartDay:1*/
		});
	};
</script>
<body bgcolor="pink">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <link rel="stylesheet" type="text/css" media="all" href="jsDatePick_ltr.min.css" />


<tr>
<center><td><img SRC="DDA.jpg"  width=80%></center>
</td>
</tr>
</table>
<br>
<br>

<table bgcolor="blue" align="center" width=40% border="1">
<tr>
<td><center><font size=6>Grievance Registration Form</td>
</tr>
</table>
<br>
<br>

<table bgcolor="silver" align="center" width=20% border="1">
<tr>
<td><center><font size=6>Personal Details</td>
</tr>
</table>

<table  border="0" align="center" cellpadding="0" cellspacing="2">
<tr>
<td><form name="form1" method="post" action="insert.php">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
</tr>


<br>
<tr>
<td width="71">Name:</td>
<td width="6">:</td>
<td width="301"><input name="Name" type="text" id="Name" autocomplete="off"></td>
</tr>

<tr>
<td width="71">Date of birth:</td>
<td width="6">:</td>
<td width="301"><input name="inputField" type="text" id="inputField" autocomplete="off"></td>
</tr>

<tr>
<td>Address:</td>
<td>:</td>
<td><textarea name="Address" cols="40" rows="6" class="widebox" id="Address"></textarea></td>
</tr>

<tr>
	<td align="center">District <td>:</td>
<td>
<select name="District" style="width: 150px;">
<option value="Darya Ganj">--SELECT--</option>
<option value=""></option>    
<option value="Central Delhi">Central Delhi</option>
    <option value="New Delhi">New Delhi</option>
    <option value="North Delhi">North Delhi</option>
	<option value="North East Delhi">North East Delhi</option>
    <option value="North West Delhi">North West Delhi</option>
	<option value="South Delhi">South Delhi</option>
	<option value="South West Delhi">South West Delhi</option>
	<option value="East Delhi">East Delhi</option>
	<option value="West Delhi">West Delhi</option>

    </select>
</tr>
  

<tr>
	<td align="center">Locality <td>:</td>
<td><select name="Locality" style="width: 150px;">
	<option value="Darya Ganj">--SELECT--</option>
<option value=""></option>
	<option value="Darya Ganj">--CENTRAL DELHI--</option>
<option value=""></option>
    <option value="Darya Ganj">Darya Ganj</option>
    <option value="Chandini Mahal">Chandini Mahal</option>
    <option value="Turkman Gate">Turkman Gate</option>
    <option value="Jama Masjid">Jama Masjid</option>
<option value="Kamla Market">Kamla Market</option>
    <option value="Shahganj">Shahganj</option>
    <option value="Hauz Quazi">Hauz Quazi</option>
    <option value="Balli maran">Balli maran</option>
<option value="Lal kaun">Lal kaun</option>
    <option value="I.P. Estate">I.P. Estate</option>
    <option value="Pahar Ganj">Pahar Ganj</option>
    <option value="DBG Road">DBG Road</option>
<option value="Shidipura">Shidipura</option>
    <option value="Govt. Qtr. Dev Nagar">Govt. Qtr. Dev Nagar</option>
    <option value="Karol Bagh">Karol Bagh</option>
    <option value="Prasad Nagar">Prasad Nagar</option>
<option value="Rajender Nagar">Rajender Nagar</option>
    <option value="Pusa Road">Pusa Road</option>
    <option value="Sita Ram Bazar">Sita Ram Bazar</option>
    <option value="Sangtrashan">Sangtrashan</option>
<option value="Nabi Karim">Nabi Karim</option>
    
<option value=""></option>
	<option value="Darya Ganj">--NEW DELHI--</option>
<option value=""></option>

    <option value="Chanakya Puri">Chanakya Puri</option>
    <option value="Connaught Place">Connaught Place</option>
    <option value="North Avenue">North Avenue</option>
    <option value="South Avenue">South Avenue</option>
    <option value="Malcha Marg">Malcha Marg</option>
<option value="Panckuian Road">Panckuian Road</option>
    <option value="Gole Market">Gole Market</option>
    <option value="Tuglak Road">Tuglak Road</option>
    <option value="Mandi House">Mandi House</option>
<option value="Bapa Nagar">Bapa Nagar</option>
    <option value="Rabindra Nagar">Rabindra Nagar</option>
    <option value="Kaka Nagar">Kaka Nagar</option>
    
<option value=""></option>
	<option value="Darya Ganj">--NORTH DELHI--</option>
<option value=""></option>


<option value="Civil Lines">Civil Lines</option>
<option value="Bela Road">Bela Road</option>
    <option value="Majnu Ka Tila">Majnu Ka Tila</option>
    <option value="Sant Ngar">Sant Ngar</option>
    <option value="Roop Nagar">Roop Nagar</option>
<option value="Maurice Nagar">Maurice Nagar</option>
    <option value="Shakti Nagar">Shakti Nagar</option>
    <option value="Subzi mandi">Subzi mandi</option>
    <option value="Tis Hazari">Tis Hazari</option>
<option value="Rana Pratap Bagh">Rana Pratap Bagh</option>
    <option value="Andha Mugal">Andha Mugal</option>
    <option value="Gulabi Bagh">Gulabi Bagh</option>
    <option value="Sarai Rohilla">Sarai Rohilla</option>
<option value="Inder Lok">Inder Lok</option>
    <option value="Sadar Bazar">Sadar Bazar</option>
    <option value="Ahata Kedara">Ahata Kedara</option>
    <option value="Bara Hindu Rao">Bara Hindu Rao</option>
<option value="Kashmere Gate">Kashmere Gate</option>
    <option value="Kotwali">Kotwali</option>
    <option value="Mori Gate">Mori Gate</option>
<option value="Red Fort">Red Fort</option>
    <option value="Yamuna Bazar">Yamuna Bazar</option>
    <option value="Lahori Gate">Lahori Gate</option>
    <option value="Church Mission">Church Mission</option>
<option value="Town Hall">Town Hall</option>
    <option value="Nai Sarak">Nai Sarak</option>
    <option value="Chandni Chowk">Chandni Chowk</option>

<option value=""></option>
	<option value="Darya Ganj">--NORTH EAST DELHI--</option>
<option value=""></option>

    <option value="Seelampur">Seelampur</option>
<option value="Gokul Puri">Gokul Puri</option>
    <option value="Khazuri Khas">Khazuri Khas</option>
    <option value="Karawal Nagar">Karawal Nagar</option>
    <option value="Bhajan Pura">Bhajan Pura</option>
<option value="Yamuna Vihar Gamri">Yamuna Vihar Gamri</option>
    <option value="Shahdra">Shahdra</option>
    <option value="Welcome Colony">Welcome Colony</option>
    <option value="Mansarover Park">Mansarover Park</option>
<option value="Seema Puri">Seema Puri</option>
    <option value="G.T.B. Nagar">G.T.B. Nagar</option>
    <option value="Nand Nagri">Nand Nagri</option>
    <option value="Ashok Nagar">Ashok Nagar</option>
<option value="Sunder Nagri">Sunder Nagri</option>
    <option value="Harsh Vihar">Harsh Vihar</option>

<option value=""></option>
	<option value="Darya Ganj">--NORTH WEST DELHI--</option>
<option value=""></option>

    <option value="Sultanpuri">Sultanpuri</option>
    <option value="Mangolpuri">Mangolpuri</option>
<option value="Narela">Narela</option>
    <option value="Kanjhawala">Kanjhawala</option>
    <option value="Ashok Vihar">Ashok Vihar</option>
    <option value="Wazirpur">Wazirpur</option>
<option value="Saraswati Vihar">Saraswati Vihar</option>
    <option value="Pitampura">Pitampura</option>
    <option value="Rani Bagh">Rani Bagh</option>
    <option value="Prashant Vihar">Prashant Vihar</option>
<option value="Jahangirpuri">Jahangirpuri</option>
    <option value="Adarsh Nagar">Adarsh Nagar</option>
    <option value="Bawana">Bawana</option>
    <option value="Alipur">Alipur</option>
<option value="Auchandi Border">Auchandi Border</option>
    <option value="Sameypur-Bodli">Sameypur-Bodli</option>
    <option value="Mukherjee Nagar">Mukherjee Nagar</option>
    <option value="Azadpur">Azadpur</option>
<option value="Model Town">Model Town</option>
    <option value="Sangam Park">Sangam Park</option>
    <option value="Vijay Nagar">Vijay Nagar</option>
    <option value="Keshav Puram">Keshav Puram</option>
<option value="Shalimar Bagh">Shalimar Bagh</option>
    <option value="Rohini">Rohini</option>
    <option value="Kingsway Camp">Kingsway Camp</option>

 
 <option value=""></option>
	<option value="Darya Ganj">--SOUTH DELHI--</option>
<option value=""></option>

    <option value="Hauz Khaz">Hauz Khaz</option>
<option value="Malviya Nagar">Malviya Nagar</option>
    <option value="Saket">Saket</option>
    <option value="Pushp Vihar">Pushp Vihar</option>
    <option value="Mehrauli">Mehrauli</option>
<option value="Defence Colony">Defence Colony</option>
    <option value="Gul Mohar Park">Gul Mohar Park</option>
    <option value="Lodhi Colony">Lodhi Colony</option>
    <option value="Pragati Vihar">Pragati Vihar</option>
<option value="Khanpur">Khanpur</option>
    <option value="Lajpat Nagar">Lajpat Nagar</option>
    <option value="Amar Colony">Amar Colony</option>
    <option value="Garthi">Garthi</option>
<option value="Okhla">Okhla</option>
    <option value="Sunlight Colony">Sunlight Colony</option>
    <option value="New Friends Colony">New Friends Colony</option>
    <option value="Sukhdev Vihar">Sukhdev Vihar</option>
<option value="Bharat Nagar">Bharat Nagar</option>
    <option value="Hz. Nizammudin">Hz. Nizammudin</option>
    <option value="Jangpura">Jangpura</option>
    <option value="Sarai Kale Khan">Sarai Kale Khan</option>
<option value="Greater Kailash">Greater Kailash</option>
    <option value="Chitranjan Park">Chitranjan Park</option>
    <option value="Ambedkar Nagar">Ambedkar Nagar</option>
    <option value="Madangir">Madangir</option>
<option value="Sainik Farm">Sainik Farm</option>
    <option value="Kalkaji">Kalkaji</option>
    <option value="Nehru Place">Nehru Place</option>
    <option value="Badarpur">Badarpur</option>
<option value="Sarita Vihar">Sarita Vihar</option>
    <option value="Sangam Vihar">Sangam Vihar</option>
    <option value="Kidwai Nagar">Kidwai Nagar</option>
    <option value="Panchasheel">Panchasheel</option>


<option value=""></option>
	<option value="Darya Ganj">--SOUTH WEST DELHI--</option>
<option value=""></option>

<option value="Vasant Vihar">Vasant Vihar</option>
    <option value="Vasant Kunj">Vasant Kunj</option>
    <option value="Nanak Pura">Nanak Pura</option>
    <option value="Vinay Nagar">Vinay Nagar</option>
<option value="R.K. Puram">R.K. Puram</option>
    <option value="Delhi Cantt.">Delhi Cantt.</option>
    <option value="Dhaula Kuan">Dhaula Kuan</option>
    <option value="Palam Colony">Palam Colony</option>
<option value="Palam Village">Palam Village</option>
    <option value="Dabri">Dabri</option>
    <option value="Raghu Nagar">Raghu Nagar</option>
    <option value="Naraina">Naraina</option>
<option value="Inderpuri">Inderpuri</option>
    <option value="Mayapuri">Mayapuri</option>
    <option value="Najaf garh">Najaf garh</option>
    <option value="Kapashera">Kapashera</option>
<option value="Jaffer pur">Jaffer pur</option>
    <option value="Samalakha">Samalakha</option>

<option value=""></option>
	<option value="Darya Ganj">--EAST DELHI--</option>
<option value=""></option>


    <option value="Kalyanpuri">Kalyanpuri</option>
    <option value="New Ashok Nagar">New Ashok Nagar</option>
<option value="Trilokpuri">Trilokpuri</option>
    <option value="Mayur Vihar I & II">Mayur Vihar I & II</option>
    <option value="Mandawali Fazad">Mandawali Fazad</option>
    <option value="Vivek Vihar">Vivek Vihar</option>
<option value="Laxmi Nagar">Laxmi Nagar</option>
    <option value="Patparganj">Patparganj</option>
    <option value="Gazipur">Gazipur</option>
    <option value="Anaz Mandi">Anaz Mandi</option>
<option value="Anand Vihar">Anand Vihar</option>
    <option value="Karkardooma">Karkardooma</option>
    <option value="Preet Vihar">Preet Vihar</option>
    <option value="Shakarpur">Shakarpur</option>
<option value="Gandhi Nagar">Gandhi Nagar</option>
    <option value="Krishna Nagar">Krishna Nagar</option>
    <option value="Gita Colony">Gita Colony</option>
    <option value="Sheelampur">Sheelampur</option>
<option value="Jheel">Jheel</option>


<option value=""></option>
	<option value="Darya Ganj">--WEST DELHI--</option>
<option value=""></option>

    <option value="Patel Nagar">Patel Nagar</option>
    <option value="Anand Parbat">Anand Parbat</option>
    <option value="Moti Nagar">Moti Nagar</option>
<option value="Tilak Nagar">Tilak Nagar</option>
    <option value="Khayala">Khayala</option>
    <option value="Janakpuri">Janakpuri</option>
    <option value="Uttam Nagar">Uttam Nagar</option>
<option value="Matiyala">Matiyala</option>
    <option value="Punjabi Bagh">Punjabi Bagh</option>
    <option value="Vikas Puri">Vikas Puri</option>
	<option value="Dwarka">Dwarka</option>
    <option value="Meera Bagh">Meera Bagh</option>
<option value="Madipur">Madipur</option>
    <option value="Paschim Vihar">Paschim Vihar</option>
    <option value="Miawali Nagar">Miawali Nagar</option>
    <option value="Mangolpuri">Mangolpuri</option>
<option value="Tikri Border">Tikri Border</option>
    <option value="Raja Garden">Raja Garden</option>
    <option value="Rajouri Garden">Rajouri Garden</option>
    <option value="Mansarover Garden">Mansarover Garden</option>
<option value="Hari Nagar">Hari Nagar</option>
    <option value="Kirti Nagar">Kirti Nagar</option>
    <option value="Raghubir Nagar">Raghubir Nagar</option>
    <option value="Nangloi">Nangloi</option>
    </select>

</tr>




<tr>
<td>PIN Code:</td>
<td>:</td>
<td><input name="PIN_Code" type="text" id="PIN_Code" autocomplete="off"></td>
</tr>


<tr>
<td>State:</td>
<td>:</td>
<td><input name="State" type="text" id="State" autocomplete="off"></td>
</tr>

<tr>
<td>Landline Number:</td>
<td>:</td>
<td><input name="Landline" type="text" id="Landline" autocomplete="off"></td>
</tr>

<tr>
<td>Mobile Number:</td>
<td>:</td>
<td><input name="Mobile" type="text" id="Mobile" autocomplete="off"></td>
</tr>

<tr>
<td>Email</td>
<td>:</td>
<td><input name="Email" type="text" id="Email" autocomplete="off"></td>
</tr>

</table>
</td>
</tr>
</table>

<table bgcolor="silver" align="center" width=20% border="1">
<tr>
<td><center><font size=6>Grievance Details</td>
</tr>
</table>

<table width="300" border="0" align="center" cellpadding="0" cellspacing="2">
<tr>
<td><form name="form1" method="post" action="insert.php">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
</tr>
<br>

<tr>
<td>Enter Department:</td>
<td>:</td>
<td><input name="Dept" type="text" id="Dept" autocomplete="off"></td>
</tr>

<tr>
<td>Officer:</td>
<td>:</td>
<td><input name="Officer" type="text" id="Officer" autocomplete="off"></td>
</tr>

<tr>
<td>Landline Number:</td>
<td>:</td>
<td><input name="Landline_No" type="text" id="Landline_No" autocomplete="off"></td>
</tr>

<tr>
<td>Mobile Number:</td>
<td>:</td>
<td><input name="Mobile_No" type="text" id="Mobile_No" autocomplete="off"></td>
</tr>

<tr>
<td>Enter your Grievance:</td>
<td>:</td>
<td><textarea name="Description" cols="60" rows="8" class="widebox" id="Description"></textarea></td>
</tr>

<tr>
<td>Enter Your Form Number/ Grievance ID</td>
<td>:</td>
<td><input name="Grievance_ID" type="text" id="Grievance_ID" autocomplete="off"></td>
</tr>

<tr>
<td colspan="3" align="center"><input type="submit" name="Submit" value="Submit"></td>
</tr>

</table>
</form>
<p><font color=red>*</font>Use your form number for tracking status of your grievance</p>
</table>
<br>

<hr size=3" color=black>
<p><font size=4><center>||<a href="http://www.dda.org.in">DDA website<a>||<a href="contact.php">Contact Us<a>||<a href="Index.php">Home<a>||</p>
<p><font size=4><center>Copyright � 2015 www.dda.org.in</p>
<hr size=3" color=black>
<body>
<html>
