<?php

if(isset($_SESSION['Grievance_ID'])){
header("location: checkstatus.php");
}
?>

<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>database connections</title>
    </head>
    <body background="abc.jpg">
	<tr>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<table bgcolor="silver" align="center" width=20% border="1">
<tr>
<td><center><font size=6>SEARCH BY NAME</td>
</tr>
</table>
<br>
<br>

<table width="300" border="0" align="center" cellpadding="0" cellspacing="1">
<tr>
<td><form name="form1" method="post" action="getsearch.php">
<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
</tr>

<tr>
<td width="71">Enter Name:</td>
<td width="6">:</td>
<td width="301"><input name="Name" type="text" id="Name" autocomplete="off"></td>
</tr>

<tr>
<td colspan="3" align="center"><input type="submit" name="Submit" value="Search"></td>
</tr>

</table>
</form>
</table>
<br>

<hr size=3" color=black>
<p><font size=4><center>||<a href="Profile.php">Home<a>||</p>
<p><font size=4><center>Copyright � 2015</p>
<hr size=3" color=black>
      
    </body>
    </html>