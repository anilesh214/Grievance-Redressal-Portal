<html>
<head>
<title>Public Grievances</title>
</head>
<body bgcolor="pink">
<tr>
<center><td><img SRC="DDA.jpg"  width=80%></center>
</td>
</tr>
</table>
<br>
<br>

<table bgcolor="sky blue" align="center" width=60% >
<tr>
<td><center><font size=5>Welcome to Online Public Grievance Lodging and Monitoring System </td>
</tr>
</table>

<br>
<br>
<table bgcolor="blue" align="center" width=40% border="1">
<tr>
<td><center><font size=6>CITIZEN CORNER</td>
</tr>
</table>
<br>
<table align="center" width=40% border="1">
<tr>
<td><center><b><a href="Lodge.php">Lodge your grievance here.<a></b></td>
</tr>
</table>
<br>
<table align="center" width=40% border="1">
<tr>
<td><center><b><a href="Status.php">View Status of your grievance.<a></b></td>
</tr>
</table>

<br>
<br>

<br>
<br>

<table bgcolor="orange" align="center" width=40% border="1">
<tr>
<td><center><font size=6>Login</td>
</tr>
</table>
<br>
<table align="center" width=40% border="1">
<tr>
<td><center><b><a href="Login.php">Login for Administrator<a></b></td>
</tr>
</table>
<br>
<br>
<table bgcolor="#2875AE" align="center" width=100% border="1">
<td><marquee>* Recommended Browsers * 1. Microsoft Internet Explorer 7.0 or higher for Windows (get latest Internet Explorer browser) ******2. Mozilla Firefox 3.0 or higher for Mac, Windows, and Linux (get latest Firefox browser)</marquee></td>
</table>
<hr size=3" color=black>
<p><font size=4><center>Copyright � 2019 </p>
<hr size=3" color=black>
<body>
<html>
