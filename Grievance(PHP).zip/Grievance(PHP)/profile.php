 <!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>database connections</title>
    </head>
    <body background="abc.jpg">
	<tr>

      <?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
      $result = mysql_query("SELECT * FROM lodge where Status='pending' ");
      ?>
	<br>
	<br>
	<br>
	<br>
	<br>
	<hr size=3" color=black>
	<b id="logout"><a href="logout.php">Log Out</a></b>
	<b><a href="reports.php" style="float: right;">Reports</a></b>
	<hr size=3" color=black>
	<br>
	<br>
	<br>
	<br>
<form name="form1" method="post" action="list.php">	
<p><center><font color=red><h1>Pending List</h1>
      <table border="2" style= "background-color: ivory; color: blue; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Grievance_ID</th>
          <th>Name</th>
	<th>Address</th>
	<th>PIN Code</th>
	<th>State</th>
	<th>Landline</th>
	<th>Mobile Number</th>
	<th>Email</th>
	<th>Department</th>
	<th>Grievance</th>
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              
              <td>{$row\['Name'\]}</td> 
	      <td>{$row\['Address'\]}</td> 
	      <td>{$row\['PIN_Code'\]}</td> 
	      <td>{$row\['State'\]}</td> 
	      <td>{$row\['Landline'\]}</td> 
	      <td>{$row\['Mobile'\]}</td> 
	      <td>{$row\['Email'\]}</td> 
	      <td>{$row\['Dept'\]}</td>
	      <td>{$row\['Description'\]}</td> 
	      
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>
	<tr>
<center><td  colspan="3" align="center"><input type="submit" name="submit" value="Continue"></td>
</tr>
     <?php mysql_close($connector); ?>
    </body>
    </html>