<html>
<head>
<title>Reports</title>
</head>
<body bgcolor="pink">
<tr>
<center><td><img SRC="DDA.jpg"  width=80%></center>
</td>
</tr>
</table>
<br>
<br>
<hr size=3" color=black>
	<b id="logout"><a href="profile.php">Back</a></b>
	<hr size=3" color=black>
<table bgcolor="sky blue" align="center" width=60% >
<br>
<br>
<tr>
<td><center><font size=5>REPORTS INFORMATION</td>
</tr>
</table>

<br>
<br>

<table align="center" width=40% border="1">
<tr>
<td><center><b><a href="monthly.php">Monthly Reports<a></b></td>
</tr>
</table>
<br>
<br>
<table align="center" width=40% border="1">
<tr>
<td><center><b><a href="age.php">Age Wise Reports<a></b></td>
</tr>
</table>
<br>
<br>
<table align="center" width=40% border="1">
<tr>
<td><center><b><a href="district.php">District Wise Reports<a></b></td>
</tr>
</table>
<br>
<br>
<table align="center" width=40% border="1">
<tr>
<td><center><b><a href="date.php">Custom Date Reports Reports<a></b></td>
</tr>
</table>
<table bgcolor="#2875AE" align="center" width=100% border="1">
<td><marquee>* Recommended Browsers * 1. Microsoft Internet Explorer 7.0 or higher for Windows (get latest Internet Explorer browser) ******2. Mozilla Firefox 3.0 or higher for Mac, Windows, and Linux (get latest Firefox browser)</marquee></td>
</table>
<hr size=3" color=black>
<p><font size=4><center>||<a href="http://www.dda.org.in">DDA website<a>||<a href="contact.php">Contact Us<a>||</p>
<p><font size=4><center>Copyright � 2015 </p>
<hr size=3" color=black>
<body>
<html>
