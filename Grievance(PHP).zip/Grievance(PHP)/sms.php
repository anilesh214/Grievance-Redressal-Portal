<!doctype html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <title>database connections</title>
    </head>
    <body background="abc.jpg">
	<tr>

      <?php
      $username = "root";
      $password = "22754196";
      $host = "localhost";

      $connector = mysql_connect($host,$username,$password)
          or die("Unable to connect");
      $selected = mysql_select_db("grievance", $connector)
        or die("Unable to connect");

      //execute the SQL query and return records
      $result = mysql_query("SELECT * FROM lodge where Status = 'Resolved'");
      ?>
	<br>
	<br>
	<br>
	<br>
	<br>
	<hr size=3" color=black>
	<b id="Back"><a href="profile.php">Back</a></b>
	<hr size=3" color=black>
	<br>
	<br>
	<br>
	<br>

<p><center><font color=Blue><h1>Resolved List</h1>
      <table border="2" style= "background-color: #84ed86; color: black; margin: 0 auto;" >
      <thead>
        <tr>
          <th>Form Number</th>
          <th>Name</th>
	<th>D.O.B</th>
	<th>Address</th>
	<th>PIN Code</th>
	<th>State</th>
	<th>Landline</th>
	<th>Mobile</th>
	<th>Email</th>
	 <th>Department</th>
	<th>Grievance</th>
	<th>Details</th>
	
        </tr>
      </thead>
      <tbody>
        <?php
          while( $row = mysql_fetch_assoc( $result ) ){
            echo
            "<tr>
              <td>{$row\['Grievance_ID'\]}</td>
              <td>{$row\['Name'\]}</td> 
	 <td>{$row\['inputField'\]}</td> 
	      <td>{$row\['Address'\]}</td> 
	      <td>{$row\['PIN_Code'\]}</td> 
	      <td>{$row\['State'\]}</td> 
	      <td>{$row\['Landline'\]}</td> 
	      <td>{$row\['Mobile'\]}</td> 
	      <td>{$row\['Email'\]}</td> 
		<td>{$row\['Dept'\]}</td>
	      <td>{$row\['Description'\]}</td> 
	      <td>{$row\['Action'\]}</td> 
            </tr>\n";
          }
        ?>
      </tbody>
    </table>
<br>
<br>
<script type="text/javascript">
// Popup window code
function newPopup(url) {
	popupWindow = window.open(
		url,'popUpWindow','height=500,width=600,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
}
</script>
<a href="JavaScript:newPopup('http://smsc.dolphin.mtnldelhi.in/');">Send SMS</a>
 </body>
</html>